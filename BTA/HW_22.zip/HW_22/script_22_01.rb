#a. Create method "my_method" with following:

# 1. Define method "my_method"

def my_method

end

#2.Variable "name" has value "Your Name".

def my_method

  name = "Nick"        # It should be your name

end

#3.      Print the statement: Hello your name (using variable) plus an exclamation mark.

def my_method

  name = "Nick"

  print "Hello #{name} !"

end

#b.      Call this method

my_method