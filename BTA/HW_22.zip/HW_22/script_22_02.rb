#a.      Create method "my_method_param" with parameter "name" and do following:

#  1.      Define method "my_method_param"
def my_method()
end
#2.      Print the statement: Hello your name (using variable) plus an exclamation mark.

def my_method(name)
print "Hello #{name} !"
end
#b.      Call this method with passing parameter "name" with value - "Your Name"

my_method("Nick")

