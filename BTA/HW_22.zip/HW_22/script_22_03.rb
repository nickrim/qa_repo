#a.      Define the method "my_method_param_default" with parameter "name" with default value "Your Name":

#Print the statement: Hello Your Name (using variable) plus an exclamation mark.

 def my_method_param_default(name="John")

print "Hello #{name} !"
 end
#b.      Call this method WITHOUT passing parameter.

my_method_param_default()

#c.       Call this method with parameter "name" and value "Some other Name"

my_method_param_default("Alex")


