#a.      Create method "calc_sum_two" with parameters "first" and "second" and do following:

 #    Print summary of both values (first + second)

def calc_sum_two(first, second)

  puts "the sum of #{first} and #{second} is #{first + second}"

end

#b.      Call this method with parameters "first" and "second" and values 5 and 17 correspondingly

calc_sum_two(5,17)