#	script_16_07.rb
#	Display 3 results of the comparison using <=> operator of following variables (a, b 	b, a	b, b)

a = 10
b = 3

puts a <=> b
puts b <=> a
puts b <=> b