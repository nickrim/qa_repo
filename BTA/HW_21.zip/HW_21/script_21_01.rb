#a.Create 2 empty hashes:

#1.ear

year = {}

#2.contacts

contacts = {}
#for each hash (2) provide the following info:

#1.Display the class of each hash

puts "Class of hash 'year' is: #{year.class}"
#2.Display the size of each hash

puts "Size of hash 'year' is: #{year.size}"

#3.Display all keys of each hash

puts "All keys of hash 'year': #{year.keys}"

#4.Display all values of each hash

puts "All values of hash 'year': #{year.values}"

#5.Verify if that hash is empty.

           puts "Is hash 'days' empty?: #{year.empty?}"

