#	script_16_05.rb
#	Display result of both conditions (true and false) of the logical operator "!" using following variable:  a


a = 10
b = 3
if !(a == 10 and b == 3)
puts "true"
else
puts "false"
end