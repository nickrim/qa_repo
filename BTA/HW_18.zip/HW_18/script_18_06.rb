#	script_16_06.rb
#	Display result of both conditions (true and false) of the logical operator "not" using following variables:  a

a = 10
b = 3
if not(a == 10 and b == 3)
puts "true"
else
puts "false"
end