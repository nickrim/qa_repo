# Using "puts" display the following statement and its result

var= 2+3
puts "2+3 is" , var

