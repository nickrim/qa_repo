# Using "print" display how many Roosters (петухов)

var=100 - 25 * 3 % 4
print "Roosters - " ,var
