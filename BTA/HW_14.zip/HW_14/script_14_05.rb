# Using "puts" display the following statement and its result

var = 11*6
puts "11 times 6 is ",var