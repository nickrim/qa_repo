# Using "print" display the result of the following (true of false)

var=3 + 2 < 5 - 7 
print "3 + 2 < 5 - 7 is ", var