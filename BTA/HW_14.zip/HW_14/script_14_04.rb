# Using "puts" display the following statement and its result

var = 5-7
puts "5 - 7 is", var

