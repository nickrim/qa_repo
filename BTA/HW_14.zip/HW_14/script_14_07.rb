# Using "print" display how many Hens (куриц)

var = 25 + 30 / 6
print "Hens - ",var