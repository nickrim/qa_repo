# Using "puts" display the result of the following (true of false)
var=5>10
puts "Is it true 5 greater than 10",var