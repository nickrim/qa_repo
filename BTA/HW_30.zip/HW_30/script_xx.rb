require 'watir-webdriver'



browser = Watir::Browser.new :firefox



#==========================================================================

#browser = Watir::Browser.new :ie

#browser = Watir::Browser.new :chrome

#browser = Watir::Browser.new :safari

#==========================================================================

browser.driver.manage.timeouts.implicit_wait = 5

#==========================================================================

url = "http://www.bing.com"

query = "What is Selenium?"

#==========================================================================

browser.goto url

puts "========================================"

puts "Title of bing.com: #{browser.title}"

puts "URL of bing.com: #{browser.url}"

#==========================================================================

browser.screenshot.save "bing_01.png"

browser.text_field(:id, "sb_form_q").set query

browser.button(:id, "sb_form_go").click

#==========================================================================
browser.screenshot.save "bing_02.png"
puts "========================================"
 puts "Title of result page: #{browser.title}"
puts "URL of result page: #{browser.url}"

#==========================================================================

 browser.link(:text => /eHow - eHow/).click
 browser.screenshot.save "bing_03.png"
 puts "========================================"
 puts "Title of eHow.com page: #{browser.title}"
 puts "URL of eHow.com page: #{browser.url}"

#==========================================================================

