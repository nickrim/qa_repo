#	script_17_07.rb
#	Display result of the assignment using **= operator of following variables:  c **= a

a = 10
b = 3
c = 5
c **= a

puts c

