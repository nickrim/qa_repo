#	script_17_01.rb
#	Display result of the assignment using = operator of following variables:  c = a + b

a = 10
b = 3
c = a + b

puts c
