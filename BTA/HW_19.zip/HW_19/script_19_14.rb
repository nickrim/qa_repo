#	script_19_14.rb
#	Ranges as Sequences: Display the size (how many items) in the following range: from aaa to zzz

range = ('aaa'..'zzz')
puts range.to_a.size
