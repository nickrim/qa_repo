#	script_19_06.rb
#	Display the following range: from cab to cat

range = ('cab'..'cat')
puts range.to_a
