#	script_19_10.rb
#	Display (true of false) if string cap present in the following range: from cab to cat

range = ('cab'..'cat')
puts range.include?'cap'
