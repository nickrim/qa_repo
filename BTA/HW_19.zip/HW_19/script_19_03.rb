#	script_19_03.rb
#	Display the minimum item in the following range: from 1 to 768

numbers = 1..768
puts numbers.min
