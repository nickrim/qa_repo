#	script_19_09.rb
#	Display the last item in the following range: from cab to cat

range = ('cab'..'cat')
puts range.to_a.last
