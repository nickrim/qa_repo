#	script_19_07.rb
#	Display the size (how many items) in the following range: from cab to cat

range = ('cab'..'cat')
puts range.to_a.size