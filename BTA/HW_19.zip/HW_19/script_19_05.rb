#	script_19_05.rb
#	Display the following range: from a to z

range = ('a'..'z')
puts range.to_a