#	script_19_02.rb
#	Display the following range excluding end point: from 1 to 10

numbers = 1...10
puts numbers.to_a
