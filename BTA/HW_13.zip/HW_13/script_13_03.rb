# display using puts for every line

puts "This is a multiline statement"
puts "\tusing multiple puts commands"
puts "  for each line!"