# display with 1 puts

puts "This is a multiline statement\n\tusing one puts command\n  for each line!"
