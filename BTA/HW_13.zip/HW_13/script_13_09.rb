# .length

puts "This statement contains \" double quote and ' single quote".length