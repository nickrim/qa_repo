# This statement contains \ backslash

puts "This statement contains \\ backslash"