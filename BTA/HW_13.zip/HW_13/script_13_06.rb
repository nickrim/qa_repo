# this statement contains " double quote

puts "This statement contains \" double quote"