# some Comments

puts "This statement it repeat itself twice!"*2