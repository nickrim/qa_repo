# using herodoc

puts <<EOF
This is a multiline statement

\tusing heredoc

  for each line!
EOF
