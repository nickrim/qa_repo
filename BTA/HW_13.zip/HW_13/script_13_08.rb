# This statement contains " double quote and ' single quote

 puts "This statement contains \" double quote and ' single quote"

 