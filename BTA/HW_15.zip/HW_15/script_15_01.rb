#	script_15_01.rb
#	Display result of the addition operation using following variables:  a, b

a = 10
b = 3

puts a + b
